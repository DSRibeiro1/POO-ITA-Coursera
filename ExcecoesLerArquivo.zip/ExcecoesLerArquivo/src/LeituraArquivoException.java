
public class LeituraArquivoException extends Exception {
	
	
	public LeituraArquivoException(String mensagem) {
		super(mensagem);
	}
}

	
	


